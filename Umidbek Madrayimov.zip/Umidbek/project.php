<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- mobile metas -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="viewport" content="initial-scale=1, maximum-scale=1">
<!-- site metas -->
<title>Cial</title>
<meta name="keywords" content="">
<meta name="description" content="">
<meta name="author" content=""> 
<!-- bootstrap css -->
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<!-- style css -->
<link rel="stylesheet" type="text/css" href="css/style.css">
<!-- Responsive-->
<link rel="stylesheet" href="css/responsive.css">
<!-- fevicon -->
<link rel="icon" href="images/fevicon.png" type="image/gif" />
<!-- Scrollbar Custom CSS -->
<link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
<!-- Tweaks for older IEs-->
<link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
<!-- owl stylesheets --> 
<link rel="stylesheet" href="css/owl.carousel.min.css">
<link rel="stylesheet" href="css/owl.theme.default.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">

    <title>projects</title>
</head>
<body>
  <!-- As a link -->
<nav class="navbar navbar-light bg-light">
<a class="navbar-brand" href="./admin.php"> Admin oynasiga qaytish</a>
  <a class="navbar-brand" href="./create_project.php">Yangi project yaratish</a>
</nav>

<!-- table -->
<table class="table table-hover">
        <thead>
        <tr>
            <th>ID</th>
            <th>project nomi</th>
            <th>matni</th>
            <th>rasmi</th>
            <th>o'chirish</th>
            <th>o'zgartirish</th>
        </tr>
        </thead>
        <tbody>
        <?php 
        include('connection.php');
        $sql = "SELECT * FROM project";
        $result = $connection->query($sql);
        if($result->num_rows>0){
            while($row = $result->fetch_assoc())
            {
                ?>
                <tr>
<!--                    <td>--><?php //echo $row['id']?><!--</td>-->
                    <td><?php echo $row['id']?></td>
                    <td><?php echo $row['nomi']?></td>
                    
                    <td><?php echo $row['matni']?></td>
                    <td><img src="rasm/<?php echo $row['rasmi']?>" style="width=250px; height: 200px; border-radius: 30px; " alt=""></td>
                    </td>
                    <td>
                        <form action="delete_project.php" method="post">
                            <input type="hidden" name="id" value="<?php echo($row['id'])?>">
                            <button type="submit" class="btn btn-danger">O'chirish</button>

                        </form>
                    </td>
                    <td>
                    <form action="edit_project.php" method="post">
                            <input type="hidden" name="id" value="<?php echo($row['id'])?>">
                            <button type="submit" class="btn btn-primary">O'zgartirish</button>
                        </form>
                    </td>
                </tr>
            <?php }}?>
        </tbody>
    </table>



</body>
</html>