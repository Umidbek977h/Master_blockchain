<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- mobile metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="initial-scale=1, maximum-scale=1">
    <!-- site metas -->
    <title>Madrayimov Umidbek</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- owl carousel style -->
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.0.0-beta.2.4/assets/owl.carousel.min.css" />
    <!-- bootstrap css -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <!-- style css -->
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <!-- Responsive-->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- fevicon -->
    <link rel="icon" href="images/fevicon.png" type="image/gif" />
    <!-- Scrollbar Custom CSS -->
    <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
    <!-- Tweaks for older IEs-->
    <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
    <!-- fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700|Poppins:400,700&display=swap" rel="stylesheet">
    <!-- owl stylesheets -->
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
</head>

<body>
    <!--header section start -->
    <div class="header_section">
        <div class="header_bg">
            <div class="container">
                <nav class="navbar navbar-expand-lg navbar-light bg-light">
                    <a class="logo" href="index.php"><img src="images/LOGO1.png"></a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                  <span class="navbar-toggler-icon"></span>
                  </button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav mr-auto">
                            <li class="nav-item active">
                                <a class="nav-link" href="index.php">Asosiy</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="about.php">Haqida</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="services.php">Project</a>
                            </li>
                          
                            <li class="nav-item">
                                <a class="nav-link" href="contact.php">Aloqa</a>
                            </li>
                        </ul>
                        <div class="call_section">
                            <ul>
                                <li>
                                    <a href="#"><img src="images/fb-icon.png"></a>
                                </li>
                                <li>
                                    <a href="#"><img src="images/twitter-icon.png"></a>
                                </li>
                                <li>
                                    <a href="#"><img src="images/linkedin-icon.png"></a>
                                </li>
                                <li>
                                    <a href="#"><img src="images/instagram-icon.png"></a>
                                </li>

                            </ul>
                        </div>
                    </div>
                </nav>
            </div>
        </div>
        <!--banner section start -->
        <div class="banner_section layout_padding">
            <div id="my_slider" class="carousel slide" data-ride="carousel">
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <div class="container">
                            <div class="banner_taital_main">
                                <div class="row">
                                    <div class="col-md-6">
                                        <h1 class="banner_taital">MASTER BLOKCHEYN </h1>
                                        <p class="banner_text">Blokcheyn — bu deyarli barcha kriptovalyutalarning markazida joylashgan innovatsion maʼlumotlar bazasi texnologiyasi. Maʼlumotlar bazasining bir xil nusxalarini butun tarmoq boʻylab tarqatish orqali blokcheyn tizimni
                                            buzish yoki aldashni juda qiyinlashtiradi.</p>

                                    </div>
                                    <div class="col-md-6">
                                        <div class="image_1"><img src="images/img-1.png"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="container">
                            <div class="banner_taital_main">
                                <div class="row">
                                    <div class="col-md-6">
                                        <h1 class="banner_taital">MASTER BLOKCHEYN </h1>
                                        <p class="banner_text">Muxtasar qilib aytganda, blokcheyn — bu markazlashtirilmagan raqamli daftar sifatida ishlaydigan maʼlumotlar yozuvlari roʻyxati. Maʼlumotlar bloklarga boʻlingan, ular xronologik tartibda joylashtirilgan va kriptografiya
                                            bilan himoyalangan. </p>

                                    </div>
                                    <div class="col-md-6">
                                        <div class="image_1"><img src="images/img-1.png"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <div class="container">
                            <div class="banner_taital_main">
                                <div class="row">
                                    <div class="col-md-6">
                                        <h1 class="banner_taital">Blockchain tarixi</h1>
                                        <p class="banner_text">Kriptovalyutalar ortida yotgan texnologiya blokcheyn hisoblanadi. Bu tarmoqdagi har bir mijozga hech qachon bir-biriga ishonmasdan konsensusga erishish imkonini beradi. Blokcheyn texnologiyasi gʻoyasi 1991-yilda
                                            tadqiqotchi olimlar Styuart Xaber va V. Skott Stornetta raqamli hujjatlarni eskirgan yoki oʻzgartirilmasligi uchun vaqtni belgilash uchun amaliy yechimni taqdim etganlarida tasvirlangan edi. Tizim vaqt tamgʻasi
                                            boʻlgan hujjatlarni saqlash uchun kriptografik himoyalangan bloklar zanjiridan foydalangan va 1992-yilda Merkle daraxtlari dizaynga kiritilgan, bu esa bir nechta hujjatlarni bitta blokda toʻplash imkonini berish
                                            orqali uni yanada samaraliroq qilgan.</p>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="image_1"><img src="images/img-1.png"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <a class="carousel-control-prev" href="#my_slider" role="button" data-slide="prev">
                    <i class="fa fa-arrow-left" style="font-size:24px"></i>
                </a>
                <a class="carousel-control-next" href="#my_slider" role="button" data-slide="next">
                    <i class="fa fa-arrow-right" style="font-size:24px"></i>
                </a>
            </div>
        </div>
        <!--banner section end -->
    </div>
    <!--header section end -->
  
    <!-- about section start -->
    <div class="news_section layout_padding">
        <div class="container">
            <h1 class="news_taital">Blokcheyn nima?</h1>
            <p class="news_text">Blokcheyn — bu shunchaki maʼlumotlar bazasi. Bu ham unchalik murakkab emas — uni minimal kuch sarflab, elektron jadvalda yaratishingiz mumkin.</p>
            <h1 class="news_taital">Blockchain qanday ishlatiladi?</h1>
            <h3 ">Kriptovalyutada</h3>
            <p class="news_text ">Bugungi kunda blokcheyndan eng keng tarqalgan foydalanish Bitcoin yoki Ethereum kabi kriptovalyutalarning asosi hisoblanadi. Odamlar kriptovalyutani sotib olganda, almashtirganda yoki sarflaganda, tranzaktsiyalar blokcheynda qayd etiladi. Qanchalik koʻp odamlar kriptovalyutadan foydalansa, blokcheyn shunchalik keng tarqalishi mumkin.</p>
            <h3>Aqlli shartnomalarda</h3>
            <p class="news_text ">Blockchain-ning yana bir yangiligi — bu oʻz-oʻzidan bajariladigan shartnomalar, odatda „aqlli shartnomalar“ deb ataladi. Ushbu raqamli shartnomalar shartlar bajarilgandan soʻng avtomatik ravishda kuchga kiradi. Misol uchun, xaridor va sotuvchi
                bitimning barcha belgilangan parametrlarini bajargandan soʻng, tovar uchun toʻlov darhol amalga oshirilishi mumkin.</p>

            <div class="news_section_2 ">
                <div class="row ">
                    <div class="col-md-6 ">
                        <div class="news_taital_box ">
                            <p class="date_text ">04 IYUN 2002</p>
                            <h4 class="make_text ">Blokcheynning afzalliklari</h4>
                            <p class="lorem_text ">Blockchain tranzaksiyasi bir nechta tugunlar tomonidan tekshirilishi kerakligi sababli, bu xatoni kamaytirishi mumkin. Agar bitta tugun maʼlumotlar bazasida xatolikka yoʻl qoʻygan boʻlsa, boshqalari uning boshqacha ekanligini koʻradi va xatoni ushlaydi. Bundan farqli oʻlaroq, anʼanaviy maʼlumotlar bazasida,
                                                   agar kimdir xatoga yoʻl qoʻysa, undan oʻtish ehtimoli koʻproq boʻlishi mumkin. </p>
                            <p class="post_text ">Blokcheynlar 24/7 ishlayDI</p>
                        </div>
                    </div>
                    <div class="col-md-6 ">
                        <img src="images/Blockchain.webp " class="image_6 " style="width:100% ">
                        <h6 class="plus_text ">+</h6>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- about section end -->
   
       
    <!-- client section end -->
    <!-- newsletter section start -->
  
    <!-- newsletter section end -->

    <!-- contact section start -->
    <div class="contact_section layout_padding ">
        <div class="container-fluid ">
            <div class="row ">
                <div class="col-md-6 padding_left0 ">
                    <div class="mail_section ">
                        <div class="contact_img ">
                            <h1 class="contact_taital ">Master  BLOKCHEYN</h1>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 ">
                    <div class="map_main "><iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d1272.0070253196097!2d60.8939445279351!3d41.81053785030647!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e1!3m2!1sen!2s!4v1685173617297!5m2!1sen!2s
                " width="600 " height="450 " style="border:0; " allowfullscreen=" " loading="lazy " referrerpolicy="no-referrer-when-downgrade "></iframe></div>
                </div>
            </div>
        </div>
    </div>
    <!-- contact section end -->
    <!-- footer section start -->
    <div class="footer_section layout_padding ">
        <div class="container ">
                        <div class="footer_section_2 ">
                <div class="row ">
                    <div class="col-lg-3 margin_top ">
                        <div class="call_text ">
                            <a href="# "><img src="images/call-icon1.png "><span class="padding_left_15 ">Telefon +998 97 967 35 45</span></a>
                        </div>
                        <div class="call_text ">
                            <a href="# "><img src="images/mail-icon1.png "><span class="padding_left_15 ">umidbek@gmail.com</span></a>
                        </div>
                    </div>
                    <div class="col-lg-3 ">
                        <div class="information_main ">
                            <h4 class="information_text ">Ma'lumot</h4>
                            <p class="many_text ">Blokcheynni qo'llashdan tashqari, o’quv turning Gollandiya segmentida hukumat tomonidan boshqa raqamli yechimlardan foydalanish ham ko'rib chiqildi.</p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 ">
                        <div class="information_main ">
                            <h4 class="information_text ">Linklar</h4>
                            <div class="footer_menu ">
                                <ul>
                                    <li><a href="index.php ">Asosiy</a></li>
                                    <li><a href="about.php ">Haqida</a></li>
                                    <li><a href="services.php ">Xizmtlar</a></li>
                                    <li><a href="blog.php ">Blog</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 ">
                        <div class="information_main ">
                            <div class="footer_logo ">
                                <a href="index.php "><img src="images/f_logo.png "></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- footer section end -->
    <!-- copyright section start -->
    <div class="copyright_section ">
        <div class="container ">
            <p class="copyright_text ">943 -21 gruh talabasi <a href="https://html.design ">Madrayimov Umidbek</a></p>
        </div>
    </div>
    <!-- copyright section end -->
    <!-- Javascript files-->
    <script src="js/jquery.min.js "></script>
    <script src="js/popper.min.js "></script>
    <script src="js/bootstrap.bundle.min.js "></script>
    <script src="js/jquery-3.0.0.min.js "></script>
    <script src="js/plugin.js "></script>
    <!-- sidebar -->
    <script src="js/jquery.mCustomScrollbar.concat.min.js "></script>
    <script src="js/custom.js "></script>
    <!-- javascript -->
    <script src="js/owl.carousel.js "></script>
    <script src="https:cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js "></script>
</body>

</html>