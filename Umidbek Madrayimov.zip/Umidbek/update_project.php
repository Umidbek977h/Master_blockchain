<?php
include 'connection.php';

if (isset($_POST['nomi'])  && isset($_POST['matni']) ) {
    $nomi= $_POST['nomi'];
    $matni= $_POST['matni'];

    $filename = $_FILES["rasmi"]["name"];
    $tempname = $_FILES["rasmi"]["tmp_name"];
    $folder = "rasm/" . $filename;

    if(move_uploaded_file($tempname,$folder)){
        echo "rasm yuklandi!";
    }
    else echo "rasm yuklashda xatolik";

    $id = intval($_POST['id']);

    $sql = "UPDATE project SET  nomi='$nomi', matni = '$matni', rasmi='$filename' WHERE id = '$id' ";
    if ($connection->query($sql)) {
        header('Location:project.php');
    } else echo 'xato!' . $connection->error;
}
$connection->close();
