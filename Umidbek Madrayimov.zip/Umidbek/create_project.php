<?php
include 'connection.php';
if (isset($_POST['saqlash'])) {
    $nomi = $_POST['nomi'];
    $matni =$_POST['matni'];
    //rasm uchun
    $filename = $_FILES["rasmi"]["name"];
    $tempname = $_FILES["rasmi"]["tmp_name"];
    $folder = "rasm/" . $filename;
    if(move_uploaded_file($tempname,$folder)){
        echo "rasm yuklandi!";
    }
    else echo "rasm yuklashda xatolik";

    $sql = "INSERT INTO project(`nomi`, `matni`, `rasmi`) VALUES ('".addslashes($nomi)."', '".addslashes($matni)."','".addslashes($filename)."' );";
     if ($connection->query($sql)) {
        ?>
        <script !src="">alert('Saqlandi')</script>
      <?php
    } else echo 'xato!' . $connection->error;
  
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- mobile metas -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="viewport" content="initial-scale=1, maximum-scale=1">
<!-- site metas -->
<title>Cial</title>
<meta name="keywords" content="">
<meta name="description" content="">
<meta name="author" content=""> 
<!-- bootstrap css -->
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<!-- style css -->
<link rel="stylesheet" type="text/css" href="css/style.css">
<!-- Responsive-->
<link rel="stylesheet" href="css/responsive.css">
<!-- fevicon -->
<link rel="icon" href="images/fevicon.png" type="image/gif" />
<!-- Scrollbar Custom CSS -->
<link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
<!-- Tweaks for older IEs-->
<link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
<!-- owl stylesheets --> 
<link rel="stylesheet" href="css/owl.carousel.min.css">
<link rel="stylesheet" href="css/owl.theme.default.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">

    <title>Admin oynasi</title>
</head>
<body>
  <!-- As a link -->
<nav class="navbar navbar-light bg-light">
<a class="navbar-brand" href="./project.php"> Projectlarniko'rish</a>
  <a class="navbar-brand" href="./xabar.php"> Xabarlarni ko'rish</a>
</nav>

<form action="" method="post" enctype="multipart/form-data">
                            <div class="mail_section">
                                <input type="" class="mail_text_1" placeholder="nomi" name="nomi">
                                <input type="" class="mail_text_1" placeholder="maqsadi" name="maqsadi">
                                <textarea class="massage_text" placeholder="G'oya haqida" rows=" 5 " id="matni " name="matni"></textarea>
                                <input type="file" class="mail_text_1" name="rasmi">
                                <div class="send_btn ">
                                    <input type="submit" value="saqlash" name="saqlash" class="btn btn-primary">
                                </div>
                            </div>
                        </form>
</body>
</html>